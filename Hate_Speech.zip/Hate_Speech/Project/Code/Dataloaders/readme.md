> Here are the different dataloading schemes. Any transforms, data augmentation can be added here
