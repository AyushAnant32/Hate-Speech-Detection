> Here are the trainer codes for the different experiments
Feel free to add your experiment!
